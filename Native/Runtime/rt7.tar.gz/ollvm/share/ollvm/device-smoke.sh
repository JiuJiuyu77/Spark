#!/bin/sh
set -eu

# Device-side production smoke for the standalone LLVM16 strong-compile Runtime.
# Usage:
#   sh share/ollvm/device-smoke.sh /path/to/ManagedRuntimes/ollvm
# Optional:
#   CA_THEOS_SDKROOT=/path/to/iPhoneOS16.5.sdk

ROOT="${1:-${CA_TOOL_OLLVM_ROOT:-}}"
if [ -z "$ROOT" ]; then
    echo "usage: $0 <strong-compile runtime root>" >&2
    exit 2
fi

CLANG="${CA_TOOL_OLLVM_CLANG:-$ROOT/bin/clang}"
CLANGXX="$ROOT/bin/clang++"
if [ ! -x "$CLANG" ] || [ ! -x "$CLANGXX" ]; then
    echo "FAIL: strong compiler is not executable" >&2
    exit 3
fi

SDK="${CA_THEOS_SDKROOT:-${SDKROOT:-}}"
if [ -z "$SDK" ] && [ -n "${THEOS:-}" ]; then
    for candidate in "$THEOS"/sdks/iPhoneOS*.sdk; do
        [ -d "$candidate" ] && SDK="$candidate"
    done
fi
if [ -z "$SDK" ] || [ ! -d "$SDK/System/Library/Frameworks/Foundation.framework" ]; then
    echo "FAIL: iPhoneOS SDK not found; set CA_THEOS_SDKROOT or THEOS" >&2
    exit 4
fi

TMP_BASE="${TMPDIR:-/tmp}"
WORK="$TMP_BASE/ollvm16-device-smoke-$$"
mkdir -p "$WORK"
cleanup() { rm -rf "$WORK" 2>/dev/null || true; }
trap cleanup EXIT INT TERM

cat >"$WORK/smoke.c" <<'EOF'
volatile int ollvm_global = 7;
const char *ollvm_secret = "OLLVM16_SMOKE_SECRET_6731";
static int triple(int x) { return x * 3; }
int (*ollvm_indirect)(int) = triple;
int ollvm_dispatch(int x) {
    int value = x > 3 ? x + ollvm_global : x - ollvm_global;
    if (value & 1) value += 11; else value -= 5;
    return ollvm_indirect(value) + ollvm_secret[0];
}
EOF

cat >"$WORK/smoke.m" <<'EOF'
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
int ollvm_objc_smoke(void) {
    NSString *text = [NSString stringWithFormat:@"strong-%d", 16];
    UIView *view = [[UIView alloc] initWithFrame:CGRectZero];
    return (int)text.length + (view != nil);
}
EOF

cat >"$WORK/smoke.mm" <<'EOF'
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <vector>
int ollvm_objcxx_smoke(void) {
    std::vector<int> values{1, 2, 3};
    NSString *text = @"objcxx";
    return (int)values.size() + (int)text.length;
}
EOF

compile_obj() {
    arch="$1"
    lang="$2"
    source="$3"
    name="$4"
    shift 4
    echo "[smoke] $arch $lang $name"
    compiler="$CLANG"
    [ "$lang" = "objective-c++" ] && compiler="$CLANGXX"
    if [ "$lang" = "c" ]; then
        "$compiler" -arch "$arch" -isysroot "$SDK" -miphoneos-version-min=15.0 \
            -O1 -x "$lang" -c "$source" -o "$WORK/$name-$arch.o" "$@"
    else
        "$compiler" -arch "$arch" -isysroot "$SDK" -miphoneos-version-min=15.0 \
            -O1 -fmodules -fmodules-cache-path="$WORK/modules-$arch" -fobjc-arc \
            -x "$lang" -c "$source" -o "$WORK/$name-$arch.o" "$@"
    fi
    [ -s "$WORK/$name-$arch.o" ] || {
        echo "FAIL: empty object for $name/$arch" >&2
        exit 10
    }
}

echo "[smoke] clang --version"
"$CLANG" --version

for arch in arm64 arm64e; do
    compile_obj "$arch" c "$WORK/smoke.c" baseline
    compile_obj "$arch" objective-c "$WORK/smoke.m" foundation-uikit
    compile_obj "$arch" objective-c++ "$WORK/smoke.mm" objcxx

    compile_obj "$arch" c "$WORK/smoke.c" indbr -mllvm -irobf -mllvm --irobf-indbr
    compile_obj "$arch" c "$WORK/smoke.c" icall -mllvm -irobf -mllvm --irobf-icall
    compile_obj "$arch" c "$WORK/smoke.c" indgv -mllvm -irobf -mllvm --irobf-indgv
    compile_obj "$arch" c "$WORK/smoke.c" cse -mllvm -irobf -mllvm --irobf-cse
    compile_obj "$arch" c "$WORK/smoke.c" cff -mllvm -irobf -mllvm --irobf-cff
    compile_obj "$arch" c "$WORK/smoke.c" balanced \
        -mllvm -irobf -mllvm --irobf-indbr -mllvm --irobf-cse
done

if [ -n "${THEOS:-}" ] && [ -d "$THEOS/makefiles" ]; then
    MAKE_BIN="${CA_THEOS_MAKE:-}"
    if [ -z "$MAKE_BIN" ]; then
        MAKE_BIN="$(command -v make 2>/dev/null || true)"
    fi
    if [ -n "$MAKE_BIN" ] && [ -x "$MAKE_BIN" ]; then
        PROJECT="$WORK/theos-smoke"
        mkdir -p "$PROJECT"
        cat >"$PROJECT/Makefile" <<'EOF'
ARCHS = arm64 arm64e
TARGET = iphone:clang:latest:15.0
include $(THEOS)/makefiles/common.mk

TWEAK_NAME = StrongCompileSmoke
StrongCompileSmoke_FILES = Tweak.x Tweak.xm
StrongCompileSmoke_CFLAGS = -fobjc-arc
StrongCompileSmoke_FRAMEWORKS = Foundation UIKit

include $(THEOS_MAKE_PATH)/tweak.mk
EOF
        cat >"$PROJECT/Tweak.x" <<'EOF'
#import <UIKit/UIKit.h>
%hook UILabel
- (void)setText:(NSString *)text {
    %orig(text);
}
%end
EOF
        cat >"$PROJECT/Tweak.xm" <<'EOF'
#import <UIKit/UIKit.h>
#include <vector>
static int strong_compile_cpp(void) {
    std::vector<int> v{1, 2, 3};
    return (int)v.size();
}
%hook UIView
- (void)setNeedsLayout {
    if (strong_compile_cpp() >= 0) {
        %orig;
    }
}
%end
EOF
        cat >"$PROJECT/control" <<'EOF'
Package: com.mt.strongcompile.smoke
Name: StrongCompileSmoke
Version: 1.0
Architecture: iphoneos-arm64
Description: Strong compile runtime smoke
Maintainer: shuji
Author: shuji
Section: Tweaks
EOF
        echo "[smoke] real Theos .x/.xm package arm64+arm64e"
        (
            cd "$PROJECT"
            TARGET_CC="$CLANG" \
            TARGET_CXX="$CLANGXX" \
            TARGET_LD="$CLANG" \
            ADDITIONAL_CFLAGS="-mllvm -irobf -mllvm --irobf-indbr -mllvm --irobf-cse" \
            "$MAKE_BIN" clean package FINALPACKAGE=1
        )
    else
        echo "[smoke] WARN: Theos make unavailable; skipping full package smoke"
    fi
else
    echo "[smoke] WARN: THEOS unavailable; skipping full package smoke"
fi

echo "[smoke] PASS: arm64 + arm64e, Foundation/UIKit, ObjC/ObjC++, 5 protection passes and Theos package"
